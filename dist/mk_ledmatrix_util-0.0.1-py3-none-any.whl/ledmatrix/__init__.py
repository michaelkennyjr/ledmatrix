print('Hello Joe!')
